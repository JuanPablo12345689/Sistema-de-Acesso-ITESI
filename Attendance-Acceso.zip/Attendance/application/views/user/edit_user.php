<div class="col-lg-4 col-lg-offset-4">
    <h2>Editar Usuario</h2>
    <h5>Hola <span><?php echo $first_name; ?></span>, <br>Editar Usuario.</h5>
    <hr>
    <?php $fattr = array('class' => 'form-signin');
    echo form_open(site_url() . 'user/edit/' . $id, $fattr); ?>

    <?php
    foreach ($groups as $row) {
        $id = $row->id;
        $first_name = $row->first_name;
        $last_name = $row->last_name;
        $No_control=$row->No_control;
        $Carrera=$row->Carrera;
        $email = $row->email;
        $Semestre=$row->Semestre;
        $role = $row->role;
    }
    ?>
<div class="form-group">
        <?php echo form_input(array('name' => 'firstname', 'id' => 'firstname', 'placeholder' => 'First Name', 'class' => 'form-control', 'value' => $first_name)); ?>
        <?php echo form_error('firstname'); ?>
    </div>
    <div class="form-group">
        <?php echo form_input(array('name' => 'lastname', 'id' => 'lastname', 'placeholder' => 'Apellido', 'class' => 'form-control', 'value' => $last_name)); ?>
        <?php echo form_error('lastname'); ?>
    </div>
    <div class="form-group">
        <?php echo form_input(array('name' => 'No_control', 'id' => 'No_control', 'placeholder' => 'Número de Control', 'class' => 'form-control', 'value' => $No_control)); ?>
        <?php echo form_error('No_control'); ?>
    </div>
        <div class="form-group">
        <?php
        $dd_listc = array(
            'Sistemas Computacionales' => 'Sistemas Computacionales',
            'Industrial' => 'Industrial',
            'Sistemas Automotrices' => 'Sistemas Automotices',
            'Gestion Empresarial' => 'Gestion Empresarial',
        );
        $dd_namec = "Carrera";
        echo form_dropdown($dd_namec, $dd_listc, set_value($dd_namec), 'class = "form-control" id="Carrera"');
        ?>
    </div>
        <div class="form-group">
        <?php echo form_input(array('name' => 'email', 'id' => 'email', 'placeholder' => 'Correo', 'class' => 'form-control', 'value' => $email)); ?>
        <?php echo form_error('email'); ?>
    </div>
        <div class="form-group">
        <?php
        $dd_lists = array(
            '1°' => '1°',
            '2°' => '2°',
            '3°' => '3°',
            '4°' => '4°',
            '5°' => '5°',
            '6°' => '6°',
            '7°' => '7°',
            '8°' => '8°',
            '9°' => '9°',
            'NA' => 'NA°',
        );
        $dd_names = "Semestre";
        echo form_dropdown($dd_names, $dd_lists, set_value($dd_names,$Semestre), 'class = "form-control" id="Semestre"');
        ?>
    </div>
    <div class="form-group">
        <?php
        $dd_list = array(
            '1' => 'Admin/Guardia',
            '2' => 'Docente',
            '3' => 'Alumno',
        );
        $dd_name = "role";
        echo form_dropdown($dd_name, $dd_list, set_value($dd_name,$role), 'class = "form-control" id="role"');
        ?>
    </div>
    <div class="form-group">
        <?php echo form_password(array('name' => 'password', 'id' => 'password', 'placeholder' => 'Password', 'class' => 'form-control', 'value' => set_value('password'))); ?>
        <?php echo form_error('password') ?>
    </div>
    <div class="form-group">
        <?php echo form_password(array('name' => 'passconf', 'id' => 'passconf', 'placeholder' => 'Confirm Password', 'class' => 'form-control', 'value' => set_value('passconf'))); ?>
        <?php echo form_error('passconf') ?>
    </div>
    <?php echo form_submit(array('value' => 'Guardar', 'class' => 'btn btn-lg btn-primary btn-block')); ?>
    <a href="<?php echo site_url() . 'user/'; ?>">
        <button type="button" class="btn btn-default btn-lg btn-block">Cancelar</button>
    </a>
    <?php echo form_close(); ?>
</div>
