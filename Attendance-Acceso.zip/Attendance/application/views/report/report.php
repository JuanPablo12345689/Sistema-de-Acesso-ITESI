<div class="container">
    <h2>Reporte</h2>
    <hr>

    <div class="well">
        <p id="date_filter" class="form-inline">
            <span id="date-label-from" class="date-label"><b>De:</b> </span><input
                    class="date_range_filter date form-control input-sm" placeholder="Fecha De" type="text" id="min"/>
            <span id="date-label-to" class="date-label"><b>A:</b> <input
                        class="date_range_filter date form-control input-sm" placeholder="Fecha A" type="text"
                        id="max"/>
        </p>
    </div>

    <div class="table-responsive">
        <table id="data-table" class="display" cellspacing="0" width="100%">
            <thead>
            <tr>
                <th>
                    No.
                </th>
                <th>
                    Datos del usuario
                </th>

                <th>
                    Fecha
                </th>
                <th>
                    Hora Entrada
                </th>
                <th>
                    Hora Salida
                </th>
                <th>
                    Horas Dentro 
                </th>
                <th>
                    Tiempo Extra
                </th>
                <th>
                    Tiempo de Retardo
                </th>
                <th>
                    Hora de Salida Temprana
                </th>
                <th>
                    En ubicación
                </th>
                <th>
                    Fuera de ubicación
                </th>
            </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
</div>

</div><!--row-->

