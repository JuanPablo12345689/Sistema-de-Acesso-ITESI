</div><!--row-->

<footer>
    <div class="col-md-12 footer-space">
        <hr>
        Copyright&copy; - <?php echo date('Y'); ?> | Creado por Ing. en Sistemas Computacionales</a>
    </div>
</footer>
</div><!-- /container -->

<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title" id="myModalLabel">Sistema Control de Acceso ITESI Tarimoro</h4>
            </div>
            <div class="modal-body">
                <h2>Version</h2>
                <p>V1.0</p>
                <h2>Acerca de</h2>
                <p>Control de Acceso ITESI Tarimoro 
                <p>Si tienes alguna pregunta, envíeme un correo electrónico: <a
                            href="mailto:dudas_itesi@gmail.com">dudas_itesi@gmail.com</a><br>
                    Visita: <a href="https://connectwithdev.com/page/contact"
                              rel="nofollow">https://irapuato.tecnm.mx/</a></p>
                <h2>Integrantes del proyecto:</h2>
                <p>Jesús, Orlando, Karla, Liz, Gina, Juan Pablo</p>
                <p>Copyright&copy; <?php echo date('Y'); ?>, Sistemas Computacionales 6to Semestre</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
            </div>
        </div>
    </div>
</div>


<!-- /Load Js -->
<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js" type="text/javascript"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<script src="<?php echo base_url() . 'public/js/main.js' ?>"></script>
<script>var baseUrl = "<?php echo base_url(); ?>";</script>

<?php
// Inline data
if (isset($data_js) && is_array($data_js)) {
    foreach ($data_js as $data) {
        echo '<script>' . $data . '</script>';
    }
}

// Load another js
if (isset($js_to_load) && is_array($js_to_load)) {
    foreach ($js_to_load as $row) {
        echo '<script src="' . base_url() . 'public/js/' . $row . '"></script>';
    }
}
?>
</body>
</html>
