<div class="center-word">
    <div class="page-header">
        <h1>Email Sent Successfully.</h1>
    </div>
    <div class="alert alert-info" role="alert">
        Please check your inbox.
        <br>
        Login? <a href="<?php echo base_url() . 'main/login' ?>">login</a>
    </div>
</div>