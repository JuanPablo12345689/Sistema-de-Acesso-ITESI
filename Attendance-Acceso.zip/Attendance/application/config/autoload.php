<?php
defined('BASEPATH') or exit('No direct script access allowed');

/*
| -------------------------------------------------------------------
| CARGADO AUTOMÁTICO
| -------------------------------------------------------------------
| Este archivo especifica qué sistemas deben cargarse de forma predeterminada.
|
|Para mantener el marco lo más ligero posible, solo se cargan los recursos 
|mínimos absolutos de forma predeterminada. Por ejemplo, la base de datos 
|no se conecta automáticamente ya que no se asume si tiene la intención de
|utilizarla. Este archivo le permite definir globalmente qué sistemas le 
|gustaría cargar con cada solicitud.
|
| -------------------------------------------------------------------
| Instrucciones
| -------------------------------------------------------------------
|
| These are the things you can load automatically:
|
| 1. Paquetes
| 2. Librerias
| 3. Conductores
| 4. Archivos auxiliares
| 5. Archivos de configuración personalizados
| 6. Archivos de idioma
| 7. Modelos
|
*/

/*
| -------------------------------------------------------------------
|  Paquetes de carga automática
| -------------------------------------------------------------------
| Prototipo:
|
|  $autoload['packages'] = array(APPPATH.'third_party', '/usr/local/shared');
|
*/
$autoload['packages'] = array();

/*
| -------------------------------------------------------------------
| Librerias de carga automática
| -------------------------------------------------------------------
|Estas son las clases ubicadas en system/libraries/ o en el directorio 
|application/libraries/, con la adición de la biblioteca 'database', 
|que es un caso especial.
|
| Prototipo:
|
|	$autoload['libraries'] = array('database', 'email', 'session');
|
|También puede proporcionar un nombre de biblioteca alternativo para 
|asignarlo en el controlador:
|
|	$autoload['libraries'] = array('user_agent' => 'ua');
*/
$autoload['libraries'] = array('session');

/*
| -------------------------------------------------------------------
|  Controladoras de carga automática
| -------------------------------------------------------------------
|Estas clases se encuentran en system/libraries/ o en su directorio 
|application/libraries/, pero también se colocan dentro de su propio 
|subdirectorio y amplían la clase CI_Driver_Library. Ofrecen múltiples 
|opciones de controladores intercambiables.
|
| Prototipo:
|
|	$autoload['drivers'] = array('cache');
|
|También puede proporcionar un nombre de propiedad alternativo para 
|asignarlo en el controlador:
|
|	$autoload['drivers'] = array('cache' => 'cch');
|
*/
$autoload['drivers'] = array();

/*
| -------------------------------------------------------------------
| Archivos auxiliares de carga automática
| -------------------------------------------------------------------
| Prototipoe:
|
|	$autoload['helper'] = array('url', 'file');
*/
$autoload['helper'] = array('url', 'form', 'security');

/*
| -------------------------------------------------------------------
|  Carga automática de archivos de configuración
| -------------------------------------------------------------------
| Prototipoe:
|
|	$autoload['config'] = array('config1', 'config2');
|
|NOTA: Este elemento está diseñado para usarse ÚNICAMENTE si ha creado 
|archivos de configuración personalizados. De lo contrario, déjelo en 
|blanco.
|
*/
$autoload['config'] = array();

/*
| -------------------------------------------------------------------
|  Carga automática de archivos de idioma
| -------------------------------------------------------------------
| Prototipo:
|
|	$autoload['language'] = array('lang1', 'lang2');
|
| NOTA: No incluya la parte "_lang" de su archivo. Por ejemplo, se haría
| referencia a "codeigniter_lang.php" como array('codeigniter');
|
*/
$autoload['language'] = array();

/*
| -------------------------------------------------------------------
|  Modelos de carga automática
| -------------------------------------------------------------------
| Prototipo:
|
|	$autoload['model'] = array('first_model', 'second_model');
|
| 
|También puede proporcionar un nombre de modelo alternativo para asignarlo
|en el controlador:
|
|	$autoload['model'] = array('first_model' => 'first');
*/
$autoload['model'] = array();
